export type Dia = 'Lunes' | 'Martes' | 'Miércoles' | 'Jueves' | 'Viernes' | 'Sábado';

export interface ClaseHorario {
  id: number;
  grupoId: number;
  materiaId: number;
  materia: string;
  grupo: string;
  dia: Dia;
  horaInicio: number;
  horaFin: number;
  color: string;
  publicada: boolean;
}

export interface NuevaSesion {
  grupoId: number | null;
  dia: Dia;
  horaInicio: number;
}

export interface FranjaAlmuerzo {
  inicio: number;
  fin: number;
}
