import { Component, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { HorarioService } from '../services/horario.service';
import { ClaseHorario, Dia } from '../models/horario.model';
import { normalizar } from '../utils/texto';

interface Destino {
  dia: Dia;
  hora: number;
  motivo: string | null;
}

@Component({
  selector: 'app-mi-horario',
  templateUrl: './mi-horario.component.html',
  styleUrl: './mi-horario.component.css',
  standalone: false
})
export class MiHorarioComponent {
  private svc = inject(HorarioService);
  private router = inject(Router);
  auth = inject(AuthService);

  dias = this.svc.dias;
  horas = this.svc.horasGrilla;
  aviso = this.svc.avisoSesiones;
  almuerzo = this.svc.almuerzo;
  sinPublicar = this.svc.sinPublicar;
  grupos = this.svc.gruposEtiquetados;
  seleccionada = signal<ClaseHorario | null>(null);

  // Filtros
  fMateria = signal('');
  fGrupo = signal<number | null>(null);
  fId = signal<number | null>(null);
  fDia = signal<Dia | ''>('');
  fEstado = signal<'' | 'publicada' | 'borrador'>('');

  hayFiltros = computed(
    () => !!this.fMateria() || this.fGrupo() !== null || this.fId() !== null || !!this.fDia() || !!this.fEstado()
  );

  clases = computed(() => {
    const materia = normalizar(this.fMateria());
    const grupo = this.fGrupo();
    const id = this.fId();
    const dia = this.fDia();
    const estado = this.fEstado();
    return this.svc.clases().filter(
      c =>
        (!materia || normalizar(c.materia).includes(materia)) &&
        (grupo === null || c.grupoId === grupo) &&
        (id === null || c.id === id) &&
        (!dia || c.dia === dia) &&
        (!estado || c.publicada === (estado === 'publicada'))
    );
  });
  total = computed(() => this.svc.clases().length);

  // Arrastrar y soltar
  arrastrada = signal<ClaseHorario | null>(null);
  arrastreActivo = signal(false);
  destino = signal<Destino | null>(null);
  private desfase = 0;

  mensaje = signal('');
  mensajeEsError = signal(false);
  publicando = signal(false);

  // Mover desde el detalle (alternativa al arrastre, útil en pantallas táctiles)
  moverDia: Dia = 'Lunes';
  moverHora = 7;

  fmt(h: number): string {
    return this.svc.formatoHora(h);
  }

  col(dia: Dia): number {
    return this.dias.indexOf(dia) + 2;
  }

  fila(hora: number): number {
    return hora - this.horas[0] + 2;
  }

  filaFin(hora: number): number {
    return this.fila(Math.min(hora, this.horas[this.horas.length - 1] + 1));
  }

  esAlmuerzo(hora: number): boolean {
    return this.svc.esAlmuerzo(hora);
  }

  limpiarFiltros(): void {
    this.fMateria.set('');
    this.fGrupo.set(null);
    this.fId.set(null);
    this.fDia.set('');
    this.fEstado.set('');
  }

  asignarEn(dia: Dia, hora: number): void {
    if (!this.auth.esGestor() || this.esAlmuerzo(hora)) return;
    this.router.navigate(['/horario/asignar'], { queryParams: { dia, hora } });
  }

  abrir(c: ClaseHorario): void {
    this.moverDia = c.dia;
    this.moverHora = c.horaInicio;
    this.seleccionada.set(c);
  }

  horasPara(dia: Dia): number[] {
    return this.svc.horasValidas(dia);
  }

  ajustarHoraMover(): void {
    const validas = this.horasPara(this.moverDia);
    if (!validas.includes(this.moverHora)) this.moverHora = validas[0];
  }

  // ---------- Arrastrar y soltar ----------

  alIniciarArrastre(evento: DragEvent, c: ClaseHorario): void {
    if (!this.auth.esGestor() || !evento.dataTransfer) {
      evento.preventDefault();
      return;
    }
    evento.dataTransfer.effectAllowed = 'move';
    evento.dataTransfer.setData('text/plain', String(c.id));
    // Si se agarra el bloque por su mitad inferior, la sesión empieza una fila más arriba del cursor.
    const bloque = evento.currentTarget as HTMLElement;
    const altoFila = bloque.offsetHeight / (c.horaFin - c.horaInicio);
    this.desfase = Math.max(0, Math.min(c.horaFin - c.horaInicio - 1, Math.floor(evento.offsetY / altoFila)));
    this.arrastrada.set(c);
    this.mensaje.set('');
    // Se desactivan los bloques como destino un instante después: hacerlo ya cancelaría el arrastre.
    setTimeout(() => this.arrastreActivo.set(true));
  }

  alPasarSobre(evento: DragEvent, dia: Dia, hora: number): void {
    const c = this.arrastrada();
    if (!c) return;
    evento.preventDefault();
    const inicio = hora - this.desfase;
    const actual = this.destino();
    if (!actual || actual.dia !== dia || actual.hora !== inicio) {
      const mismoLugar = c.dia === dia && c.horaInicio === inicio;
      this.destino.set({ dia, hora: inicio, motivo: mismoLugar ? null : this.svc.motivoNoMover(c.id, dia, inicio) });
    }
    if (evento.dataTransfer) evento.dataTransfer.dropEffect = this.destino()?.motivo ? 'none' : 'move';
  }

  async alSoltar(evento: DragEvent, dia: Dia, hora: number): Promise<void> {
    evento.preventDefault();
    const c = this.arrastrada();
    const inicio = hora - this.desfase;
    this.terminarArrastre();
    if (c) await this.mover(c, dia, inicio);
  }

  terminarArrastre(): void {
    this.arrastrada.set(null);
    this.arrastreActivo.set(false);
    this.destino.set(null);
  }

  async moverDesdeDetalle(c: ClaseHorario): Promise<void> {
    if (await this.mover(c, this.moverDia, this.moverHora)) this.seleccionada.set(null);
  }

  private async mover(c: ClaseHorario, dia: Dia, hora: number): Promise<boolean> {
    if (c.dia === dia && c.horaInicio === hora) return true;
    const error = await this.svc.moverSesion(c.id, dia, hora);
    this.mensajeEsError.set(!!error);
    this.mensaje.set(
      error ?? `${c.materia} · Grupo ${c.grupo} se movió a ${dia}, ${this.fmt(hora)} - ${this.fmt(hora + c.horaFin - c.horaInicio)}.`
    );
    return !error;
  }

  // ---------- Publicación ----------

  async publicar(): Promise<void> {
    this.publicando.set(true);
    const error = await this.svc.publicarHorario();
    this.publicando.set(false);
    this.mensajeEsError.set(!!error);
    this.mensaje.set(error ?? 'Horario publicado: los consultantes ya ven todas las sesiones.');
  }

  async eliminar(clase: ClaseHorario): Promise<void> {
    const error = await this.svc.eliminarSesion(clase.id);
    if (error) {
      this.mensajeEsError.set(true);
      this.mensaje.set(error);
    }
    this.seleccionada.set(null);
  }
}
