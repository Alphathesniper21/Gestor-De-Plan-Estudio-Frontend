import { Injectable, computed, inject, signal } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../environments/environment';
import { GrupoDTO } from '../models/grupo.dto';
import { MateriaDTO, NuevaMateria } from '../models/materia.dto';
import { SesionDTO } from '../models/sesion.dto';
import { ClaseHorario, Dia, FranjaAlmuerzo, NuevaSesion } from '../models/horario.model';
import { AuthService } from './auth.service';
import { GRUPOS_MOCK, MATERIAS_MOCK, SESIONES_MOCK } from '../mock/horario.mock';

const CUPO_MAXIMO = 44;
const LOCAL_KEY = 'sesiones-local';
const ALMUERZO_KEY = 'parametros-almuerzo';
const PUBLICADAS_KEY = 'sesiones-publicadas';
const ALMUERZO_DEFECTO: FranjaAlmuerzo = { inicio: 12, fin: 13 };
const HORA_APERTURA = 7;
const HORA_CIERRE = 22;
const HORA_CIERRE_SABADO = 13;
const DURACION = 2;
const MSG_GRUPOS = 'El back exige rol ADMIN para crear o eliminar grupos, pero ese rol ya no existe. Pendiente de ajustar en el back.';

@Injectable({ providedIn: 'root' })
export class HorarioService {
  private http = inject(HttpClient);
  private auth = inject(AuthService);
  private readonly api = environment.apiUrl;

  readonly dias: Dia[] = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
  readonly horasGrilla = Array.from({ length: 15 }, (_, i) => i + 7);
  readonly cupoMaximo = CUPO_MAXIMO;
  readonly avisoSesiones = !environment.usarMock && !environment.sesionesEnBack;
  readonly horaApertura = HORA_APERTURA;
  readonly horaCierre = HORA_CIERRE;

  /** Franja de almuerzo configurada en Parámetros: no se puede ubicar ninguna sesión que la cruce. */
  readonly almuerzo = signal<FranjaAlmuerzo>(this.leerAlmuerzo());

  readonly materias = signal<MateriaDTO[]>(environment.usarMock ? MATERIAS_MOCK : []);
  readonly grupos = signal<GrupoDTO[]>(environment.usarMock ? GRUPOS_MOCK : []);
  readonly errorApi = signal('');
  readonly cargando = signal(false);

  private pendientes = 0;
  private readonly sesiones = signal<SesionDTO[]>(environment.usarMock ? SESIONES_MOCK : this.leerLocal());
  private readonly publicadasLocal = signal<number[]>(this.leerPublicadas());
  private readonly colores = ['#f97316', '#2563eb', '#059669', '#7c3aed', '#db2777', '#0891b2', '#ca8a04'];

  /** El gestor ve todo (borradores incluidos); el consultante solo lo publicado. */
  private readonly sesionesVisibles = computed(() =>
    this.auth.esGestor() ? this.sesiones() : this.sesiones().filter(s => this.estaPublicada(s))
  );
  readonly sinPublicar = computed(() => this.sesiones().filter(s => !this.estaPublicada(s)).length);

  readonly clases = computed(() =>
    this.sesionesVisibles().flatMap(s => {
      const clase = this.aClase(s);
      return clase ? [clase] : [];
    })
  );
  readonly totalMaterias = computed(() => this.materias().length);
  readonly totalGrupos = computed(() => this.grupos().length);
  readonly totalSesiones = computed(() => this.clases().length);
  readonly totalHoras = computed(() => this.clases().reduce((t, c) => t + c.horaFin - c.horaInicio, 0));
  readonly porDia = computed(() =>
    this.dias.map(d => ({ dia: d, sesiones: this.clases().filter(c => c.dia === d).length }))
  );

  readonly gruposEtiquetados = computed(() =>
    this.grupos().map(g => ({ id: g.id, etiqueta: `${this.nombreMateria(g.materiaId)} · Grupo ${g.numeroGrupo}` }))
  );

  readonly filasGrupos = computed(() =>
    this.grupos().map(g => ({
      grupo: g,
      materia: this.nombreMateria(g.materiaId),
      sesiones: this.sesionesVisibles().filter(s => s.grupoId === g.id).length,
      maxSesiones: this.maxSesiones(g)
    }))
  );

  constructor() {
    this.cargar();
  }

  cargar(): void {
    if (environment.usarMock) return;
    this.errorApi.set('');
    this.pendientes = environment.sesionesEnBack ? 3 : 2;
    if (environment.parametrosEnBack) this.cargarParametros();
    this.cargando.set(true);
    this.cargarMaterias();
    this.cargarGrupos();
    if (environment.sesionesEnBack) this.cargarSesiones();
  }

  formatoHora(h: number): string {
    return `${String(h).padStart(2, '0')}:00`;
  }

  colorDe(materiaId: number): string {
    return this.colores[Math.abs(materiaId) % this.colores.length];
  }

  materiaDeGrupo(grupoId: number | null): number {
    return this.grupos().find(g => g.id === grupoId)?.materiaId ?? 0;
  }

  cierreDe(dia: Dia): number {
    return dia === 'Sábado' ? HORA_CIERRE_SABADO : HORA_CIERRE;
  }

  /** true si una sesión que inicia a esa hora toca la franja de almuerzo. */
  cruzaAlmuerzo(horaInicio: number): boolean {
    const a = this.almuerzo();
    return horaInicio < a.fin && horaInicio + DURACION > a.inicio;
  }

  /** true si esa hora de la grilla está dentro de la franja de almuerzo. */
  esAlmuerzo(hora: number): boolean {
    const a = this.almuerzo();
    return hora >= a.inicio && hora < a.fin;
  }

  horasValidas(dia: Dia): number[] {
    const horas: number[] = [];
    for (let h = HORA_APERTURA; h + DURACION <= this.cierreDe(dia); h++) {
      if (!this.cruzaAlmuerzo(h)) horas.push(h);
    }
    return horas;
  }

  /** Sesiones existentes que quedarían dentro de una franja de almuerzo dada. */
  sesionesEnFranja(f: FranjaAlmuerzo): number {
    return this.sesiones().filter(s => this.hora(s.horaInicio) < f.fin && this.hora(s.horaFin) > f.inicio).length;
  }

  async guardarAlmuerzo(inicio: number | null, fin: number | null): Promise<string | null> {
    if (inicio === null || fin === null || !Number.isInteger(inicio) || !Number.isInteger(fin)) {
      return 'Selecciona la hora de inicio y de fin del almuerzo.';
    }
    if (inicio < HORA_APERTURA || fin > HORA_CIERRE) {
      return `La franja debe estar entre ${this.formatoHora(HORA_APERTURA)} y ${this.formatoHora(HORA_CIERRE)}.`;
    }
    if (fin <= inicio) return 'La hora de fin debe ser posterior a la de inicio.';
    if (!environment.usarMock && environment.parametrosEnBack) {
      const error = await this.llamar('PUT', environment.rutas.parametrosActualizar, {
        almuerzoInicio: `${this.formatoHora(inicio)}:00`,
        almuerzoFin: `${this.formatoHora(fin)}:00`
      });
      if (error) return error;
    }
    this.almuerzo.set({ inicio, fin });
    try {
      localStorage.setItem(ALMUERZO_KEY, JSON.stringify(this.almuerzo()));
    } catch {}
    return null;
  }

  async crearMateria(m: NuevaMateria): Promise<string | null> {
    if (!m.nombre.trim()) return 'Ingresa el nombre de la materia.';
    if (m.semestre < 1 || m.ncreditos < 1 || m.horasDeLaMateria < 2) return 'Revisa semestre, créditos y horas.';
    if (!environment.usarMock) {
      const error = await this.llamar('POST', '/materia/crear', { ...m });
      if (error) return error;
      this.cargarMaterias();
      return null;
    }
    this.materias.update(l => [...l, { ...m, id: this.siguienteId(l) }]);
    return null;
  }

  async actualizarMateria(m: MateriaDTO): Promise<string | null> {
    if (!m.nombre.trim()) return 'Ingresa el nombre de la materia.';
    if (m.semestre < 1 || m.ncreditos < 1 || m.horasDeLaMateria < 2) return 'Revisa semestre, créditos y horas.';
    if (!environment.usarMock) {
      const error = await this.llamar('PUT', '/materia/actualizar', {
        id: m.id,
        nombre: m.nombre,
        semestre: m.semestre,
        ncreditos: m.ncreditos,
        horasDeLaMateria: m.horasDeLaMateria,
        correlativa: m.correlativa
      });
      if (error) return error;
      this.cargarMaterias();
      return null;
    }
    this.materias.update(l => l.map(x => (x.id === m.id ? { ...m } : x)));
    return null;
  }

  async eliminarMateria(id: number): Promise<string | null> {
    if (this.grupos().some(g => g.materiaId === id)) return 'La materia tiene grupos asociados.';
    if (!environment.usarMock) {
      const error = await this.llamar('DELETE', `/materia/eliminar/${id}`);
      if (error) return error;
    }
    this.materias.update(l => l.filter(m => m.id !== id));
    return null;
  }

  async crearGrupo(materiaId: number | null, numeroGrupo: number | null, cupoPlaneado: number | null): Promise<string | null> {
    if (materiaId === null) return 'Selecciona la materia.';
    if (numeroGrupo === null || numeroGrupo < 1) return 'Ingresa el número de grupo.';
    if (cupoPlaneado === null || cupoPlaneado < 1) return 'Ingresa el cupo planeado.';
    if (cupoPlaneado > CUPO_MAXIMO) return `El cupo máximo permitido es ${CUPO_MAXIMO}.`;
    if (this.grupos().some(g => g.materiaId === materiaId && g.numeroGrupo === numeroGrupo)) {
      return 'La materia ya tiene ese número de grupo.';
    }
    if (!environment.usarMock) {
      const error = await this.llamar('POST', '/grupo/crear', { materiaId, numeroGrupo, cupoPlaneado }, MSG_GRUPOS);
      if (error) return error;
      this.cargarGrupos();
      return null;
    }
    this.grupos.update(l => [...l, { id: this.siguienteId(l), materiaId, numeroGrupo, cupoPlaneado }]);
    return null;
  }

  async eliminarGrupo(id: number): Promise<string | null> {
    if (!environment.usarMock) {
      const error = await this.llamar('DELETE', `/grupo/eliminar/${id}`, {}, MSG_GRUPOS);
      if (error) return error;
    }
    this.grupos.update(l => l.filter(g => g.id !== id));
    this.sesiones.update(l => l.filter(s => s.grupoId !== id));
    return null;
  }

  async asignarSesion(d: NuevaSesion): Promise<string | null> {
    if (d.grupoId === null) return 'Selecciona el grupo.';
    const grupo = this.grupos().find(g => g.id === d.grupoId);
    if (!grupo) return 'El grupo no existe.';
    const max = this.maxSesiones(grupo);
    if (this.sesiones().filter(s => s.grupoId === grupo.id).length >= max) {
      return `El grupo ya tiene sus ${max} sesiones semanales.`;
    }
    const invalida = this.validarUbicacion(grupo.id, d.dia, d.horaInicio);
    if (invalida) return invalida;
    const horaFin = d.horaInicio + DURACION;
    const diaNumero = this.dias.indexOf(d.dia) + 1;

    const sesion: SesionDTO = {
      id: this.siguienteId(this.sesiones()),
      grupoId: grupo.id,
      diaSemana: diaNumero,
      horaInicio: `${this.formatoHora(d.horaInicio)}:00`,
      horaFin: `${this.formatoHora(horaFin)}:00`,
      publicada: false
    };
    if (!environment.usarMock && environment.sesionesEnBack) {
      const error = await this.llamar('POST', '/sesion/crear', {
        grupoId: sesion.grupoId,
        diaSemana: sesion.diaSemana,
        horaInicio: String(sesion.horaInicio),
        horaFin: String(sesion.horaFin)
      });
      if (error) return error;
      this.cargarSesiones();
      return null;
    }
    this.sesiones.update(l => [...l, sesion]);
    this.guardarLocal();
    return null;
  }

  /** Motivo por el que una sesión no puede quedar en ese día y hora, o null si es válido. */
  motivoNoMover(id: number, dia: Dia, horaInicio: number): string | null {
    const sesion = this.sesiones().find(s => s.id === id);
    if (!sesion) return 'La sesión ya no existe.';
    return this.validarUbicacion(sesion.grupoId, dia, horaInicio, id);
  }

  /** Mueve una sesión existente a otro día y hora (arrastrar y soltar en el horario). */
  async moverSesion(id: number, dia: Dia, horaInicio: number): Promise<string | null> {
    const sesion = this.sesiones().find(s => s.id === id);
    if (!sesion) return 'La sesión ya no existe.';
    const diaNumero = this.dias.indexOf(dia) + 1;
    if (sesion.diaSemana === diaNumero && this.hora(sesion.horaInicio) === horaInicio) return null;
    const invalida = this.validarUbicacion(sesion.grupoId, dia, horaInicio, id);
    if (invalida) return invalida;

    const movida: SesionDTO = {
      ...sesion,
      diaSemana: diaNumero,
      horaInicio: `${this.formatoHora(horaInicio)}:00`,
      horaFin: `${this.formatoHora(horaInicio + DURACION)}:00`,
      publicada: false
    };
    if (!environment.usarMock && environment.sesionesEnBack) {
      const error = await this.llamar('PUT', environment.rutas.sesionActualizar, {
        id,
        grupoId: movida.grupoId,
        diaSemana: movida.diaSemana,
        horaInicio: String(movida.horaInicio),
        horaFin: String(movida.horaFin)
      });
      if (error) return error;
      this.marcarPublicadas(this.publicadasLocal().filter(x => x !== id));
      this.cargarSesiones();
      return null;
    }
    this.sesiones.update(l => l.map(s => (s.id === id ? movida : s)));
    this.marcarPublicadas(this.publicadasLocal().filter(x => x !== id));
    this.guardarLocal();
    return null;
  }

  /** Publica el horario: desde ese momento el consultante ve todas las sesiones actuales. */
  async publicarHorario(): Promise<string | null> {
    if (!environment.usarMock && environment.publicacionEnBack) {
      const error = await this.llamar('PUT', environment.rutas.sesionPublicar);
      if (error) return error;
      this.cargarSesiones();
      return null;
    }
    this.sesiones.update(l => l.map(s => ({ ...s, publicada: true })));
    this.marcarPublicadas(this.sesiones().map(s => s.id));
    this.guardarLocal();
    return null;
  }

  async eliminarSesion(id: number): Promise<string | null> {
    if (!environment.usarMock && environment.sesionesEnBack) {
      const error = await this.llamar('DELETE', `/sesion/eliminar/${id}`);
      if (error) return error;
    }
    this.sesiones.update(l => l.filter(s => s.id !== id));
    if (this.publicadasLocal().includes(id)) this.marcarPublicadas(this.publicadasLocal().filter(x => x !== id));
    this.guardarLocal();
    return null;
  }

  private cargarMaterias(): void {
    this.http.get<MateriaDTO[] | null>(`${this.api}/materia/mostrartodo`).subscribe({
      next: lista => this.materias.set(lista ?? []),
      error: e => this.errorApi.set(this.mensajeError(e))
    }).add(() => this.terminar());
  }

  private cargarGrupos(): void {
    this.http.get<GrupoDTO[] | null>(`${this.api}/grupo/mostrartodo`).subscribe({
      next: lista => this.grupos.set(lista ?? []),
      error: e => this.errorApi.set(this.mensajeError(e))
    }).add(() => this.terminar());
  }

  private cargarSesiones(): void {
    this.http.get<SesionDTO[] | null>(`${this.api}/sesion/mostrartodo`).subscribe({
      next: lista => this.sesiones.set(lista ?? []),
      error: e => this.errorApi.set(this.mensajeError(e))
    }).add(() => this.terminar());
  }

  private async llamar(metodo: 'POST' | 'PUT' | 'DELETE', ruta: string, datos: Record<string, string | number | boolean> = {}, mensaje403 = ''): Promise<string | null> {
    let params = new HttpParams();
    for (const [clave, valor] of Object.entries(datos)) params = params.set(clave, String(valor));
    try {
      await firstValueFrom(this.http.request(metodo, `${this.api}${ruta}`, { params, responseType: 'text' }));
      return null;
    } catch (e) {
      if (mensaje403 && (e as HttpErrorResponse).status === 403) return mensaje403;
      return this.mensajeError(e);
    }
  }

  private validarUbicacion(grupoId: number, dia: Dia, horaInicio: number, excluirId: number | null = null): string | null {
    const horaFin = horaInicio + DURACION;
    if (horaInicio < HORA_APERTURA || horaFin > this.cierreDe(dia)) {
      return dia === 'Sábado'
        ? `El sábado las sesiones van de ${this.formatoHora(HORA_APERTURA)} a ${this.formatoHora(HORA_CIERRE_SABADO)}.`
        : `Las sesiones duran ${DURACION} horas y van de ${this.formatoHora(HORA_APERTURA)} a ${this.formatoHora(HORA_CIERRE)}.`;
    }
    if (this.cruzaAlmuerzo(horaInicio)) {
      const a = this.almuerzo();
      return `La sesión cruza la franja de almuerzo (${this.formatoHora(a.inicio)} - ${this.formatoHora(a.fin)}).`;
    }
    const diaNumero = this.dias.indexOf(dia) + 1;
    const cruce = this.sesiones().some(
      s =>
        s.id !== excluirId &&
        s.grupoId === grupoId &&
        s.diaSemana === diaNumero &&
        horaInicio < this.hora(s.horaFin) &&
        horaFin > this.hora(s.horaInicio)
    );
    return cruce ? 'El grupo ya tiene una sesión que se cruza en ese horario.' : null;
  }

  private estaPublicada(s: SesionDTO): boolean {
    return typeof s.publicada === 'boolean' ? s.publicada : this.publicadasLocal().includes(s.id);
  }

  private marcarPublicadas(ids: number[]): void {
    this.publicadasLocal.set(ids);
    try {
      localStorage.setItem(PUBLICADAS_KEY, JSON.stringify(ids));
    } catch {}
  }

  private leerPublicadas(): number[] {
    try {
      const ids = JSON.parse(localStorage.getItem(PUBLICADAS_KEY) ?? '[]');
      return Array.isArray(ids) ? ids : [];
    } catch {
      return [];
    }
  }

  private leerAlmuerzo(): FranjaAlmuerzo {
    try {
      const f = JSON.parse(localStorage.getItem(ALMUERZO_KEY) ?? 'null');
      if (f && Number.isInteger(f.inicio) && Number.isInteger(f.fin) && f.fin > f.inicio) return { inicio: f.inicio, fin: f.fin };
    } catch {}
    return ALMUERZO_DEFECTO;
  }

  private cargarParametros(): void {
    this.http.get<Record<string, string | number[]> | null>(`${this.api}${environment.rutas.parametrosMostrar}`).subscribe({
      next: p => {
        if (!p || p['almuerzoInicio'] == null || p['almuerzoFin'] == null) return;
        const inicio = this.hora(p['almuerzoInicio']);
        const fin = this.hora(p['almuerzoFin']);
        if (fin > inicio) this.almuerzo.set({ inicio, fin });
      },
      error: e => this.errorApi.set(this.mensajeError(e))
    });
  }

  private terminar(): void {
    this.pendientes--;
    if (this.pendientes <= 0) this.cargando.set(false);
  }

  private guardarLocal(): void {
    if (environment.usarMock || environment.sesionesEnBack) return;
    try {
      localStorage.setItem(LOCAL_KEY, JSON.stringify(this.sesiones()));
    } catch {}
  }

  private leerLocal(): SesionDTO[] {
    try {
      return JSON.parse(localStorage.getItem(LOCAL_KEY) ?? '[]');
    } catch {
      return [];
    }
  }

  private maxSesiones(g: GrupoDTO): number {
    const materia = this.materias().find(m => m.id === g.materiaId);
    return materia?.sesionesSemanales ?? Math.floor((materia?.horasDeLaMateria ?? 4) / 2);
  }

  private nombreMateria(id: number): string {
    return this.materias().find(m => m.id === id)?.nombre ?? `Materia ${id}`;
  }

  private siguienteId(lista: { id: number }[]): number {
    return lista.reduce((max, x) => Math.max(max, x.id), 0) + 1;
  }

  private hora(valor: string | number[]): number {
    return Array.isArray(valor) ? valor[0] : parseInt(valor.slice(0, 2), 10);
  }

  private aClase(s: SesionDTO): ClaseHorario | null {
    const grupo = this.grupos().find(g => g.id === s.grupoId);
    if (!grupo) return null;
    return {
      id: s.id,
      grupoId: grupo.id,
      materiaId: grupo.materiaId,
      materia: this.nombreMateria(grupo.materiaId),
      grupo: String(grupo.numeroGrupo),
      dia: this.dias[s.diaSemana - 1] ?? 'Lunes',
      horaInicio: this.hora(s.horaInicio),
      horaFin: this.hora(s.horaFin),
      color: this.colorDe(grupo.materiaId),
      publicada: this.estaPublicada(s)
    };
  }

  private mensajeError(e: unknown): string {
    const err = e as HttpErrorResponse;
    if (typeof err.error === 'string' && err.error) return err.error;
    if (err.status === 403) return 'Tu rol no tiene permiso para esta acción.';
    if (err.status === 401) return 'Tu sesión expiró. Inicia sesión de nuevo.';
    return 'No se pudo conectar con el servidor.';
  }
}
