import { Component, computed, inject, signal } from '@angular/core';
import { HorarioService } from '../services/horario.service';

@Component({
  selector: 'app-parametros',
  templateUrl: './parametros.component.html',
  standalone: false
})
export class ParametrosComponent {
  private svc = inject(HorarioService);

  almuerzo = this.svc.almuerzo;
  horasInicio = Array.from({ length: this.svc.horaCierre - this.svc.horaApertura }, (_, i) => i + this.svc.horaApertura);

  inicio = signal(this.almuerzo().inicio);
  fin = signal(this.almuerzo().fin);

  horasFin = computed(() => this.horasInicio.map(h => h + 1).filter(h => h > this.inicio()));
  /** Sesiones ya asignadas que quedarían dentro de la franja que se está eligiendo. */
  afectadas = computed(() => (this.fin() > this.inicio() ? this.svc.sesionesEnFranja({ inicio: this.inicio(), fin: this.fin() }) : 0));
  sinCambios = computed(() => this.inicio() === this.almuerzo().inicio && this.fin() === this.almuerzo().fin);

  error = signal('');
  exito = signal(false);

  fmt(h: number): string {
    return this.svc.formatoHora(h);
  }

  cambiarInicio(h: number): void {
    this.inicio.set(h);
    if (this.fin() <= h) this.fin.set(h + 1);
    this.exito.set(false);
  }

  cambiarFin(h: number): void {
    this.fin.set(h);
    this.exito.set(false);
  }

  async guardar(): Promise<void> {
    const resultado = await this.svc.guardarAlmuerzo(this.inicio(), this.fin());
    this.error.set(resultado ?? '');
    this.exito.set(!resultado);
  }
}
