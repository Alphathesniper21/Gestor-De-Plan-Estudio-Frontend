export const environment = {
  apiUrl: 'http://localhost:8080',
  usarMock: false,
  sesionesEnBack: true,
  // true cuando el back guarde la franja de almuerzo y el estado de publicación.
  // Mientras sea false, ambos se guardan en el navegador (localStorage).
  parametrosEnBack: false,
  publicacionEnBack: false,
  // Rutas del back usadas por las funciones nuevas. Ajustar aquí si el back usa otros nombres.
  rutas: {
    usuarioActualizar: '/usuario/actualizar',
    sesionActualizar: '/sesion/actualizar',
    sesionPublicar: '/sesion/publicar',
    parametrosMostrar: '/parametro/mostrar',
    parametrosActualizar: '/parametro/actualizar'
  }
};
